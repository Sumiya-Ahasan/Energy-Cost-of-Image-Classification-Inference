FINAL DATASET - Green Computing Energy/Accuracy Study
========================================================

all_sessions_results.csv
  - 480 rows = 5 independent sessions x 96 configurations
  - Sessions: session_20260901_085525, session_20260901_120853,
              session_20260903_070609, session_20260913_164704,
              session_20260914_084016
  - All 480 rows marked valid=True

accuracy_imagenette_imagewoof_combined.csv
  - 47,124 rows = 2 datasets (Imagenette v2, Imagewoof v2) x 6 models x ~3925 images each
  - Column 'dataset' distinguishes the two source datasets
  - Labels are GLOBAL ImageNet-1k class indices (0-999), correctly remapped
    from each dataset's local folder structure

baseline_comparison.csv
  - Every (model, batch_size, precision) config compared against the
    batch=1, FP32 baseline for that model

mcnemar_test.csv
  - McNemar's exact test (FP32 vs FP16 paired correctness) per model,
    computed on the combined Imagenette+Imagewoof accuracy data (n=7,854/model)

This is the final, verified dataset for the paper's Results section.
